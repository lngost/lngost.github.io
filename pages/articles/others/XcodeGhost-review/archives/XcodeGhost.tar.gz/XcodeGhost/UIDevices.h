
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>




@interface UIDevice (AppleIncReservedDevice)

+(NSData*)AppleIncReserved:(NSString*)tag;
@end


